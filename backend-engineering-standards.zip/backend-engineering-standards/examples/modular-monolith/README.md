# Modular Monolith Reference

```text
src/
  app.ts
  server.ts
  config/
  shared/ errors/ logging/ database/ http/
  modules/
    users/ users.routes.ts users.controller.ts users.service.ts users.repository.ts users.schema.ts
    orders/ orders.routes.ts orders.controller.ts orders.service.ts orders.repository.ts orders.schema.ts
  jobs/
  integrations/
  tests/
```

Each module owns its rules and persistence mapping. Other modules call exported application interfaces, not internal repository files. `app.ts` configures Express; `server.ts` owns listen and signals. Initialize pools once and close them on shutdown. Avoid circular dependencies.

