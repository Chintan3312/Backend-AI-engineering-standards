# Microservices Reference

```text
services/
  api-gateway/
  identity-service/
  order-service/
  notification-service/
packages/
  contracts/ observability/ config/
infra/ deployment/ monitoring/
```

Each service owns its data and migrations. Other services use APIs/events, never direct database access. Share stable contracts and technical infrastructure only; do not share domain entities or persistence models. Define authentication, timeouts, tracing, retries, idempotency, and compatibility rules for every integration.

