# Express + TypeScript Bootstrap Pattern

Conceptual example, not a complete runnable starter.

```ts
// app.ts
import express from "express";
export function createApp() {
  const app = express();
  app.disable("x-powered-by");
  app.use(express.json({ limit: "1mb" }));
  app.get("/health/live", (_req, res) => res.json({ status: "ok" }));
  // Register routers, not-found handler, then centralized error handler.
  return app;
}

// server.ts: initialize dependencies before listen; handle SIGTERM/SIGINT.
```

Use import extensions and module settings required by the selected Node.js/TypeScript configuration.

