# Monorepo Reference

```text
repo/
  apps/api/
  apps/worker/
  services/identity/
  services/orders/
  packages/config/
  packages/logger/
  packages/contracts/
  tooling/
  pnpm-workspace.yaml
```

Choose npm, pnpm, or Yarn workspaces and document the choice. Keep service build/deploy boundaries independent, define package ownership/public exports, avoid circular dependencies, and ensure CI checks affected packages plus required integration/contract tests.

