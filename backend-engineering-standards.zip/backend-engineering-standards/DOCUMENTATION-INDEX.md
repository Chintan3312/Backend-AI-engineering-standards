# Documentation Index

- `01-project-foundation/` — Project Foundation
- `02-architecture/` — Architecture
- `03-folder-structure/` — Folder Structure
- `04-coding-standards/` — Coding Standards
- `05-reusable-functionality/` — Reusable Functionality
- `06-api-and-middleware/` — Api And Middleware
- `07-database-management/` — Database Management
- `08-communication-and-integrations/` — Communication And Integrations
- `09-background-processing/` — Background Processing
- `10-ai-integration/` — Ai Integration
- `11-security-standards/` — Security Standards
- `12-testing-and-quality/` — Testing And Quality
- `13-performance-and-scalability/` — Performance And Scalability
- `14-observability-and-monitoring/` — Observability And Monitoring
- `15-development-and-deployment/` — Development And Deployment
- `16-ai-development-guidelines/` — Ai Development Guidelines
- `framework-specific/` — Specific
- `examples/` — modular monolith, microservices, monorepo, and Express/TypeScript examples
- `adr/` — Architecture Decision Records
- Root guides — dependency selection, initialization, and production readiness

