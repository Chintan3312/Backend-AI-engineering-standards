# Testing Strategy

## Purpose

Define the project-wide standard for testing strategy in Node.js, Express.js, and TypeScript applications. Apply it consistently while respecting the selected architecture and operational constraints.

## Scope

Applies to Node.js services using Express.js and TypeScript unless a project explicitly documents another choice.

## Why this matters

Clear standards reduce accidental coupling, inconsistent behavior, security gaps, and repeated implementation decisions. They also give AI coding assistants durable project context.

## When to use it

Use this guidance when creating, reviewing, or refactoring functionality related to **testing strategy**. Inspect existing project conventions before introducing a new pattern.

## Recommended approach

- Define one responsibility, an owner, and a clear interface.
- Keep business rules independent of HTTP, database, and provider-specific details.
- Validate untrusted data at system boundaries.
- Make dependencies explicit and replaceable in tests.
- Set timeouts, resource limits, and bounded retry policies.
- Record cross-cutting or hard-to-reverse decisions as ADRs.
- Prefer the simplest approach that satisfies current requirements; avoid speculative abstractions.

## Code placement

Place business behavior in the owning feature/module. Put shared technical infrastructure in a shared package only when multiple modules genuinely need the same stable capability. Avoid turning `utils` or `common` into an unowned dumping ground.

## Example

```ts
// Keep the boundary explicit: validate external input, call an application service,
// and translate the result into a stable transport response.
interface CreateRecordInput { name: string }
interface RecordRepository { create(input: CreateRecordInput): Promise<{ id: string }> }

class CreateRecordService {
  constructor(private readonly records: RecordRepository) {}
  execute(input: CreateRecordInput) {
    return this.records.create(input);
  }
}
```

## Error handling

Distinguish validation, authentication, authorization, conflict, dependency, and unexpected failures. Preserve causes for internal diagnosis while returning stable, safe client errors. Never expose stack traces, credentials, SQL, or raw provider errors.

## Security considerations

Treat request data, files, webhooks, queue messages, database records, and AI output as untrusted. Apply least privilege, runtime validation, safe logging, resource limits, and authorization checks.

## Testing requirements

- Unit-test core behavior and edge cases.
- Test invalid input and failure paths.
- Add integration tests for framework, database, network, or queue behavior where relevant.
- Verify authorization and tenant/resource isolation for protected operations.
- Keep tests deterministic and clean up external resources.

## Do

- Follow existing architecture and naming conventions.
- Prefer explicit contracts and small interfaces.
- Measure before optimizing.
- Document operational assumptions and trade-offs.

## Don't

- Over-engineer a simple requirement.
- Hide dependencies in global mutable state.
- Swallow errors or return fabricated success data.
- Retry unsafe operations without idempotency.
- Log tokens, passwords, secrets, or unnecessary personal data.

## Related documentation

See `DOCUMENTATION-INDEX.md`, `AGENTS.md`, and the relevant sibling documents in this module.
