# Backend Engineering Standards

Reusable standards and AI project-context documentation for Node.js, Express.js, and TypeScript. Supports modular monoliths, microservices, and monorepos.

## Core principles
- Prefer a modular monolith until independent deployment, scaling, ownership, or fault isolation justifies microservices.
- Use TypeScript by default.
- Keep transport, business logic, and infrastructure separate.
- Keep controllers thin and validate all external input.
- Reuse managed database pools and close resources gracefully.
- Keep secrets out of source control, logs, prompts, and client bundles.
- Test behavior, failure paths, and security boundaries.
- Treat AI-generated code and model output as untrusted until reviewed and tested.

## How to use
1. Read `AGENTS.md` and `DOCUMENTATION-INDEX.md`.
2. Select the architecture in `02-architecture/`.
3. Read relevant API, database, security, testing, and deployment standards.
4. Adapt examples; do not install every optional dependency.
5. Record important decisions in `adr/`.

This is a standards/reference package, not a runnable starter. Verify package versions and compatibility before installing dependencies.

