# Dependency Guide

Treat this as a selection guide, not a blanket install list. Verify current versions, Node.js engine support, TypeScript types, maintenance, license, security advisories, and compatibility before adoption.

| Concern | Options | Guidance |
|---|---|---|
| HTTP | Express | Required for the Express path in this standard |
| TypeScript | TypeScript, tsx | Recommended toolchain |
| Runtime validation | Zod, Joi, Ajv | Choose one consistent schema approach |
| Logging | Pino, Winston | Structured logs; redact sensitive fields |
| PostgreSQL | pg | Only if PostgreSQL is selected; use a shared pool |
| MongoDB | Official driver, Mongoose | Choose driver vs ODM intentionally |
| Redis | redis, ioredis | Optional for caching/coordination/queues |
| Password hashing | Argon2id, bcrypt | Required for password authentication |
| HTTP client | fetch, Axios | Set timeouts and normalize errors |
| Scheduling | node-cron | In-process scheduling only |
| Queues | BullMQ, RabbitMQ, Kafka | Choose by delivery, ordering, throughput, and ops needs |
| Testing | Vitest, Jest | Select one and keep tests deterministic |
| API contracts | OpenAPI tooling | Recommended for documented APIs |
| Observability | OpenTelemetry | Add when operational needs justify it |

Start with framework, TypeScript, config validation, logger, one database driver, validation, security middleware, and tests. Add optional systems only when required. Separate runtime and development dependencies; keep lockfiles committed and scan dependencies in CI.

