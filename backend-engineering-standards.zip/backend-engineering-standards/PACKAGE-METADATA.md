# Package Metadata

- Package: Backend Engineering Standards
- Stack: Node.js, Express.js, TypeScript (JavaScript supported)
- Architecture: modular monolith, microservices, monorepo
- Markdown documents: 146
- Purpose: reusable standards and reference documentation, not a runnable starter
- Link validation: 0 broken relative links detected during packaging
