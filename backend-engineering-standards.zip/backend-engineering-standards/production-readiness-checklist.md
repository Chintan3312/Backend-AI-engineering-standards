# Production Readiness Checklist

## Reliability
- [ ] Timeouts exist for inbound and outbound work.
- [ ] Retries are bounded, backed off, and safe/idempotent.
- [ ] Jobs and consumers handle duplicate delivery.
- [ ] Migrations have a safe rollout/rollback plan.

## Security
- [ ] Secrets are managed securely and never committed.
- [ ] Authentication, authorization, and tenant isolation are tested.
- [ ] External inputs are validated.
- [ ] Rate limits and abuse controls are configured.
- [ ] Logs exclude secrets, tokens, and unnecessary personal data.
- [ ] Dependencies and images are scanned.

## Data and operations
- [ ] Backups are configured and restore is tested.
- [ ] Pool limits fit database capacity across replicas.
- [ ] Critical queries and indexes are reviewed.
- [ ] Liveness/readiness checks are correct.
- [ ] Logs, metrics, traces, alerts, and runbooks exist.
- [ ] Graceful shutdown drains work and closes resources.
- [ ] Capacity/load tests cover expected traffic.

## Release
- [ ] CI passes lint, type-check, tests, and build.
- [ ] API compatibility and migrations are reviewed.
- [ ] Rollback or forward-fix procedure is understood.

