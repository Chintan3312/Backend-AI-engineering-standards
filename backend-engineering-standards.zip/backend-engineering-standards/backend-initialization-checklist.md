# Backend Initialization Checklist

## Decisions
- [ ] Confirm requirements and non-functional requirements.
- [ ] Prefer modular monolith unless a documented reason requires services.
- [ ] Select supported Node.js and TypeScript versions.
- [ ] Define data ownership, API contracts, auth, and error contract.
- [ ] Define environments, deployment target, and operational ownership.

## Repository
- [ ] Initialize Git, branch protection, README, license, and `.gitignore`.
- [ ] Select package manager and commit lockfile.
- [ ] Configure TypeScript, lint, format, and scripts.
- [ ] Add `.env.example` with placeholders only.
- [ ] Validate configuration at startup.

## Application
- [ ] Separate Express app configuration from server listen.
- [ ] Register middleware in deliberate order.
- [ ] Add request/correlation ID, 404, and centralized error handler.
- [ ] Add liveness/readiness endpoints.
- [ ] Initialize database clients once and reuse pools.
- [ ] Implement graceful shutdown and resource cleanup.

## Quality and delivery
- [ ] Add unit/integration tests and CI checks.
- [ ] Validate external input and enforce authorization.
- [ ] Configure safe logging, security headers, CORS, and rate limits.
- [ ] Document local setup, deployment, and runbooks.
- [ ] Record important decisions as ADRs.

