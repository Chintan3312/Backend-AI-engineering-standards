# AGENTS.md — Backend Engineering Instructions

Before changing code, read `README.md`, `DOCUMENTATION-INDEX.md`, and the relevant architecture and module standards. Inspect the existing codebase, scripts, tests, and conventions first.

## Mandatory rules
- TypeScript by default unless the project explicitly uses JavaScript.
- Keep controllers focused on HTTP translation; business rules belong in application/domain services.
- Never put database queries or third-party provider logic directly in controllers.
- Reuse the established database pool/client; never create a pool per request.
- Validate request, webhook, queue, file, and AI data at runtime.
- Use centralized safe error handling and structured logging. Never expose secrets, tokens, stack traces, or sensitive data.
- Prefer composition and explicit interfaces; use dependency injection where it improves testability.
- Do not share business logic or database models across independently deployable services.
- Make retries bounded and safe; use idempotency for retried jobs and message consumers.
- Do not add dependencies without explaining need, alternatives, and operational cost.
- Add/update tests for behavior, edge cases, and failure paths.
- Update documentation when architecture or operational behavior changes.

## Architecture choice
Prefer a modular monolith unless independent deployment, scaling, ownership, or fault isolation justify services. In microservices, each service owns its data and publishes explicit versioned contracts.

## Required workflow
1. Explain the approach and affected modules. 2. Inspect existing patterns. 3. Implement the smallest coherent change. 4. Add tests and docs. 5. Run available format, lint, type-check, tests, and build. 6. Report exactly what ran and what could not run.

Do not rewrite unrelated modules, silently change public contracts, swallow errors, or assume distributed guarantees that infrastructure does not provide.

