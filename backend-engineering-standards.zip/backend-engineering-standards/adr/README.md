# Architecture Decision Records

Use ADRs for cross-cutting or expensive-to-reverse decisions. Name files `NNNN-short-title.md`.

## Template

```md
# ADR NNNN: Decision title
- Status: Proposed | Accepted | Superseded | Deprecated
- Date: YYYY-MM-DD
- Owners: Team/role

## Context
Problem, constraints, and forces.
## Decision
Chosen approach and rationale.
## Alternatives considered
Viable options and why they were not selected.
## Consequences
Benefits, trade-offs, operational impact, and risks.
## Follow-up
Migration, monitoring, and review actions.
```

