# Contributing

Keep documents actionable and aligned with `AGENTS.md`. Verify relative links. Mark dependencies required/recommended/optional. Do not claim versions are current without verification. Include security, failure handling, and testing guidance. Update the documentation index when adding modules.

